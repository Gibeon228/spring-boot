package ru.gb.springdemo.demo;

import org.springframework.stereotype.Component;

@Component
public class MyService {
}
